"""Application configuration for Visual Assistant API."""

import os


class Config:
    """Base configuration."""

    # Flask
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")
    DEBUG = False
    TESTING = False

    # Upload limits
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    MAX_IMAGE_WIDTH = 4096
    MAX_IMAGE_HEIGHT = 4096
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
    ALLOWED_EXTENSIONS = {"jpeg", "jpg", "png", "gif", "webp"}

    # Rate limiting
    RATELIMIT_STORAGE_URI = "memory://"
    RATELIMIT_STRATEGY = "fixed-window"
    UPLOAD_RATE_LIMIT = "1000 per hour"
    CHAT_RATE_LIMIT = "1000 per minute"
    GLOBAL_RATE_LIMIT = "10000 per hour"
    # Session
    SESSION_TIMEOUT_HOURS = 24
    SESSION_COOKIE_NAME = "va_session_id"

    # Chat
    MAX_PROMPT_LENGTH = 10_000

    # OpenAI mock
    MOCK_MODEL_NAME = "gpt-4-vision-preview"
    MOCK_VISION_DELAY = 0.1  # seconds
    MOCK_CHAT_DELAY = 0.2  # seconds

    # Streaming (Question 2)
    MAX_STREAMING_CONNECTIONS = 50  # Max concurrent SSE connections
    STREAM_TIMEOUT_SECONDS = 30  # Max duration of a single stream

    # Conversation History (Question 3)
    HISTORY_RETENTION_DAYS = 30  # Delete conversations older than this
    HISTORY_GRACE_PERIOD_DAYS = 7  # Keep active conversations this many additional days
    HISTORY_CLEANUP_INTERVAL_SECONDS = 3600  # Run cleanup every hour
    HISTORY_MAX_MESSAGES = 50  # Max messages to include in AI context
    HISTORY_MAX_TOKENS = 10_000  # Max tokens to include in AI context



class DevelopmentConfig(Config):
    """Development configuration."""

    DEBUG = True


class TestingConfig(Config):
    """Testing configuration."""

    TESTING = True
    UPLOAD_FOLDER = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "test_uploads"
    )
    MOCK_VISION_DELAY = 0  # No delays in tests
    MOCK_CHAT_DELAY = 0
    STREAM_TIMEOUT_SECONDS = 5  # Short timeout for tests


config_by_name = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": Config,
}
