"""Conversation history retrieval endpoints."""

from flask import Blueprint, request, jsonify

from src.utils.openai_formatter import format_error_response
from src.api.chat import get_conversation_service

# Blueprint for history-related endpoints
history_bp = Blueprint("history", __name__)


@history_bp.route("/history", methods=["GET"])
def get_history():
    """Retrieve conversation history filtered by image_id, session_id, or unfiltered.

    Implements: User Story 3 (View and Navigate Conversation History)
    Implements: Session Persistence (FR-019) - History survives session changes

    Query Parameters:
        - image_id (optional): Filter conversations by image ID
        - session_id (optional): Filter conversations by session ID
        - limit (optional, default=20, max=100): Max conversations to return

    Returns:
        200: HistoryResponse with conversations and messages
        500: Internal server error

    Note: If both image_id and session_id are provided, returns conversations
    matching BOTH filters. If neither provided, returns ALL conversations
    (supports session persistence - users can retrieve history across sessions).
    """
    # Get query parameters
    image_id = request.args.get("image_id", None)
    session_id = request.args.get("session_id", None)
    limit = request.args.get("limit", 20, type=int)

    # Validate limit range
    if limit < 1 or limit > 100:
        return jsonify(
            format_error_response(
                message="Limit must be between 1 and 100",
                error_type="invalid_request_error",
                param="limit",
                code="invalid_limit",
            )
        ), 400

    # Retrieve conversations from service
    conversation_service = get_conversation_service()
    conversations = []

    try:
        # If no filters provided, get ALL conversations (enables session persistence)
        if not image_id and not session_id:
            # Get all conversations (sorted by most recent first)
            from src.database.connection import get_db_session
            with get_db_session() as db_session:
                from src.models.conversation import Conversation
                from sqlalchemy import desc
                
                all_conversations = db_session.query(Conversation).order_by(
                    desc(Conversation.last_activity)
                ).limit(limit).all()
                
                conversations = all_conversations
        else:
            # Retrieve by image_id
            if image_id:
                conversations.extend(conversation_service.get_conversations_by_image(image_id))

            # Retrieve by session_id (if also provided, merge results)
            if session_id:
                session_conversations = conversation_service.get_conversations_by_session(
                    session_id
                )

                # If both filters provided, find intersection (conversations matching BOTH)
                if image_id:
                    # Filter to only conversations that match both image_id AND session_id
                    session_conversation_ids = {c.conversation_id for c in session_conversations}
                    conversations = [
                        c for c in conversations if c.conversation_id in session_conversation_ids
                    ]
                else:
                    conversations.extend(session_conversations)

        # Remove duplicates (if any)
        seen = set()
        unique_conversations = []
        for conv in conversations:
            if conv.conversation_id not in seen:
                seen.add(conv.conversation_id)
                unique_conversations.append(conv)
        conversations = unique_conversations

        # Sort by last_activity descending (most recent first)
        conversations.sort(key=lambda c: c.last_activity, reverse=True)

        # Apply limit
        conversations = conversations[:limit]

        # Build response payload using cached conversation details
        response_conversations = []
        for conv in conversations:
            # Get conversation details (uses cache for performance)
            conv_details = conversation_service.get_conversation_details(
                conv.conversation_id
            )
            if conv_details:
                response_conversations.append(conv_details)

        return jsonify(
            {
                "conversations": response_conversations,
                "count": len(response_conversations),
            }
        ), 200

    except Exception as e:
        # Log error but return generic error to client
        from src.utils.logger import setup_logger

        logger = setup_logger(__name__)
        logger.error(f"Failed to retrieve conversation history: {e}", exc_info=True)

        return jsonify(
            format_error_response(
                message="An error occurred while retrieving conversation history",
                error_type="api_error",
                code="history_retrieval_failed",
            )
        ), 500
