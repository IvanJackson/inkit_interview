"""Message model for individual conversation turns with SQLAlchemy ORM mapping."""

from datetime import datetime
from sqlalchemy import Column, String, Integer, DateTime, Text, ForeignKey, CheckConstraint
from sqlalchemy.sql import func
from .base import Base


class Message(Base):
    """
    Represents a single message in a conversation.

    Can be from either the user or the assistant (role field).
    Includes token count estimation for context window management.

    SQLAlchemy ORM model that replaces the previous dataclass implementation.
    """

    __tablename__ = 'messages'

    # Primary key
    message_id = Column(String(36), primary_key=True)  # UUID

    # Foreign key
    conversation_id = Column(
        String(36),
        ForeignKey('conversations.conversation_id', ondelete='CASCADE'),
        nullable=False
    )  # References Conversation.conversation_id

    # Message data
    role = Column(String(20), nullable=False)  # "user" or "assistant"
    content = Column(Text, nullable=False)  # Message text, max 50,000 characters
    created_at = Column(
        DateTime,
        nullable=False,
        default=func.now(),
        server_default=func.now()
    )
    token_count = Column(Integer, nullable=False, default=0)  # Estimated tokens

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "role IN ('user', 'assistant')",
            name='chk_message_role'
        ),
    )

    def __init__(
        self,
        message_id: str,
        conversation_id: str,
        role: str,
        content: str,
        created_at: datetime = None,
        token_count: int = 0
    ):
        """Initialize Message with validation."""
        # Validate role
        valid_roles = {"user", "assistant"}
        if role not in valid_roles:
            raise ValueError(
                f"Invalid role: {role}. Must be one of {valid_roles}"
            )

        # Validate content length
        if len(content) > 50_000:
            raise ValueError(
                f"Content exceeds maximum length of 50,000 characters "
                f"(got {len(content)})"
            )

        self.message_id = message_id
        self.conversation_id = conversation_id
        self.role = role
        self.content = content
        self.created_at = created_at or datetime.utcnow()

        # Compute token count if not explicitly provided
        if token_count == 0:
            # Rough estimation: word_count * 2
            # This matches the pattern in mock_openai_service.py
            self.token_count = len(content.split()) * 2
        else:
            self.token_count = token_count

    def __repr__(self):
        return (
            f"<Message(message_id='{self.message_id}', "
            f"role='{self.role}', token_count={self.token_count})>"
        )
