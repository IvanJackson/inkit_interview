"""Session model for user interaction tracking with SQLAlchemy ORM mapping."""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey
from sqlalchemy.sql import func
from .base import Base


class SessionContext(Base):
    """
    Represents a user's interaction session with persistence across disconnections.

    SQLAlchemy ORM model that replaces the previous dataclass implementation.
    """

    __tablename__ = 'sessions'

    # Primary key
    session_id = Column(String(36), primary_key=True)  # UUID

    # Session data
    current_image_id = Column(
        String(36),
        ForeignKey('images.id', ondelete='SET NULL'),
        nullable=True
    )  # ID of most recently uploaded image
    conversation_topic = Column(String(500), nullable=True)  # Conversation summary
    browser_device_id = Column(String(255), nullable=False)  # Device fingerprint

    # Timestamps
    created_at = Column(
        DateTime,
        nullable=False,
        default=func.now(),
        server_default=func.now()
    )  # Session creation timestamp (UTC)
    last_activity = Column(
        DateTime,
        nullable=False,
        default=func.now(),
        server_default=func.now()
    )  # Last request timestamp (UTC)

    # Status flags
    authenticated = Column(Boolean, nullable=False, default=False)  # Auth status
    expired = Column(Boolean, nullable=False, default=False)  # Expiration flag

    def __init__(
        self,
        session_id: str,
        current_image_id: Optional[str] = None,
        conversation_topic: Optional[str] = None,
        browser_device_id: str = "",
        created_at: datetime = None,
        last_activity: datetime = None,
        authenticated: bool = False,
        expired: bool = False
    ):
        """Initialize SessionContext."""
        self.session_id = session_id
        self.current_image_id = current_image_id
        self.conversation_topic = conversation_topic
        self.browser_device_id = browser_device_id
        self.created_at = created_at or datetime.utcnow()
        self.last_activity = last_activity or datetime.utcnow()
        self.authenticated = authenticated
        self.expired = expired

    def __repr__(self):
        return (
            f"<SessionContext(session_id='{self.session_id}', "
            f"expired={self.expired})>"
        )

    def touch(self):
        """Update last activity timestamp."""
        self.last_activity = datetime.utcnow()

    def is_expired(self, timeout_hours: int = 24) -> bool:
        """Check if session has expired.

        Args:
            timeout_hours: Session timeout in hours

        Returns:
            True if session is expired
        """
        if self.expired:
            return True

        time_since_activity = datetime.utcnow() - self.last_activity
        hours_inactive = time_since_activity.total_seconds() / 3600

        return hours_inactive > timeout_hours

    def has_image(self) -> bool:
        """Check if session has an active image."""
        return self.current_image_id is not None
