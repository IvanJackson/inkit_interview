"""Chat request models."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class ChatRequest:
    """Represents a user's question about an image."""

    id: str  # UUID
    session_id: str  # Session making the request
    prompt: str  # User's text question/prompt (1-10,000 characters)
    image_id: Optional[str] = None  # Explicit image ID override (if None, use session.current_image_id)
    created_at: datetime = None  # Request timestamp (UTC)

    def __post_init__(self):
        """Initialize timestamp if not provided."""
        if self.created_at is None:
            self.created_at = datetime.utcnow()


