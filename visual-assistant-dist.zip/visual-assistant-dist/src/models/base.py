"""SQLAlchemy base configuration."""

from sqlalchemy.ext.declarative import declarative_base

# Create declarative base for all models
Base = declarative_base()
