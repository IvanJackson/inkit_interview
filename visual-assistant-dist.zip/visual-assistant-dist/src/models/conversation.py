"""Conversation model for multi-turn dialogue history with SQLAlchemy ORM mapping."""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.sql import func
from .base import Base


class Conversation(Base):
    """
    Represents a multi-turn conversation between user and assistant.

    Conversations are associated with an image (optional) and belong to a session.
    Tracks creation time and last activity for retention/cleanup purposes.

    SQLAlchemy ORM model that replaces the previous dataclass implementation.
    """

    __tablename__ = 'conversations'

    # Primary key
    conversation_id = Column(String(36), primary_key=True)  # UUID

    # Foreign keys
    session_id = Column(
        String(36),
        ForeignKey('sessions.session_id', ondelete='CASCADE'),
        nullable=False
    )  # References SessionContext.session_id
    image_id = Column(
        String(36),
        ForeignKey('images.id', ondelete='SET NULL'),
        nullable=True
    )  # References uploaded image, or None for text-only

    # Timestamps
    created_at = Column(
        DateTime,
        nullable=False,
        default=func.now(),
        server_default=func.now()
    )
    last_activity = Column(
        DateTime,
        nullable=False,
        default=func.now(),
        server_default=func.now()
    )

    def __init__(
        self,
        conversation_id: str,
        session_id: str,
        image_id: Optional[str] = None,
        created_at: datetime = None,
        last_activity: datetime = None
    ):
        """Initialize Conversation."""
        self.conversation_id = conversation_id
        self.session_id = session_id
        self.image_id = image_id
        self.created_at = created_at or datetime.utcnow()
        self.last_activity = last_activity or datetime.utcnow()

    def __repr__(self):
        return (
            f"<Conversation(conversation_id='{self.conversation_id}', "
            f"session_id='{self.session_id}')>"
        )

    def touch(self) -> None:
        """Update last_activity to current UTC time.

        Called whenever a new message is added to the conversation.
        """
        self.last_activity = datetime.utcnow()
