"""Image model for uploaded images with SQLAlchemy ORM mapping."""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, String, Integer, DateTime, Text, CheckConstraint
from sqlalchemy.sql import func
from .base import Base


class Image(Base):
    """
    Represents an uploaded image file with validation state and metadata.

    SQLAlchemy ORM model that replaces the previous dataclass implementation.
    """

    __tablename__ = 'images'

    # Primary key
    id = Column(String(36), primary_key=True)  # UUID

    # Image metadata
    filename = Column(String(255), nullable=False)  # Original filename (sanitized)
    size_bytes = Column(Integer, nullable=False)  # File size in bytes
    width = Column(Integer, nullable=False)  # Image width in pixels
    height = Column(Integer, nullable=False)  # Image height in pixels
    format = Column(String(10), nullable=False)  # Image format (JPEG, PNG, GIF, WebP)
    mode = Column(String(10), nullable=False)  # Color mode (RGB, RGBA, etc.)
    file_path = Column(String(512), nullable=False, unique=True)  # Storage path
    uploaded_at = Column(
        DateTime,
        nullable=False,
        default=func.now(),
        server_default=func.now()
    )  # Upload timestamp (UTC)

    # Validation and analysis
    corruption_status = Column(
        String(20),
        nullable=False,
        default='valid'
    )  # "valid", "suspected", "confirmed"
    preview_data = Column(Text, nullable=True)  # Base64-encoded preview
    vision_analysis = Column(Text, nullable=True)  # AI vision analysis result

    # Constraints
    __table_args__ = (
        CheckConstraint(
            "corruption_status IN ('valid', 'suspected', 'confirmed')",
            name='chk_corruption_status'
        ),
        CheckConstraint(
            'size_bytes >= 0',
            name='chk_size_positive'
        ),
        CheckConstraint(
            'width > 0 AND height > 0',
            name='chk_dimensions'
        ),
    )

    def __init__(
        self,
        id: str,
        filename: str,
        size_bytes: int,
        width: int,
        height: int,
        format: str,
        mode: str,
        file_path: str,
        uploaded_at: datetime = None,
        corruption_status: str = 'valid',
        preview_data: Optional[str] = None,
        vision_analysis: Optional[str] = None
    ):
        """Initialize Image with validation."""
        self.id = id
        self.filename = filename
        self.size_bytes = size_bytes
        self.width = width
        self.height = height
        self.format = format
        self.mode = mode
        self.file_path = file_path
        self.uploaded_at = uploaded_at or datetime.utcnow()
        self.corruption_status = corruption_status
        self.preview_data = preview_data
        self.vision_analysis = vision_analysis

        # Validate corruption status
        valid_statuses = {"valid", "suspected", "confirmed"}
        if self.corruption_status not in valid_statuses:
            raise ValueError(
                f"Invalid corruption_status: {self.corruption_status}. "
                f"Must be one of {valid_statuses}"
            )

    def __repr__(self):
        return (
            f"<Image(id='{self.id}', filename='{self.filename}', "
            f"corruption_status='{self.corruption_status}')>"
        )

    def is_valid(self) -> bool:
        """Check if image is valid (not corrupted)."""
        return self.corruption_status == "valid"

    def is_corrupted(self) -> bool:
        """Check if image is confirmed corrupted."""
        return self.corruption_status == "confirmed"

    def requires_confirmation(self) -> bool:
        """Check if image requires user confirmation."""
        return self.corruption_status == "suspected"
