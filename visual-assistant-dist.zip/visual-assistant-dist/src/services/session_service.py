"""Session management service."""

import hashlib
import uuid
from datetime import datetime
from typing import Optional

from src.models.session import SessionContext
from src.database.connection import get_db_session
from src.database.errors import retry_on_db_error


class SessionService:
    """Service for session management with database persistence."""

    def __init__(self, session_timeout_hours: int = 24):
        """Initialize session service.

        Args:
            session_timeout_hours: Session timeout in hours (default: 24)
        """
        self.session_timeout_hours = session_timeout_hours

    @retry_on_db_error(max_attempts=3)
    def create_session(self, browser_device_id: str) -> SessionContext:
        """Create a new session and save to database.

        Args:
            browser_device_id: Browser/device fingerprint

        Returns:
            New SessionContext instance
        """
        session = SessionContext(
            session_id=str(uuid.uuid4()),
            browser_device_id=browser_device_id,
            created_at=datetime.utcnow(),
            last_activity=datetime.utcnow(),
            authenticated=True,  # Cookie-based identity (Phase 1)
        )

        with get_db_session() as db_session:
            db_session.add(session)

        return session

    @retry_on_db_error(max_attempts=3)
    def get_session(self, session_id: str) -> Optional[SessionContext]:
        """Retrieve session from database and check for expiry.

        Args:
            session_id: Session ID

        Returns:
            SessionContext or None if not found/expired
        """
        with get_db_session() as db_session:
            session = db_session.query(SessionContext).filter(
                SessionContext.session_id == session_id
            ).first()

            if not session:
                return None

            # Check expiry
            if session.is_expired(self.session_timeout_hours):
                # Mark as expired in database
                session.expired = True
                db_session.add(session)
                return None

            return session

    @retry_on_db_error(max_attempts=3)
    def update_session(self, session: SessionContext) -> None:
        """Update session and touch last_activity timestamp in database.

        Args:
            session: Session to update
        """
        session.touch()
        with get_db_session() as db_session:
            db_session.merge(session)

    def get_or_create_session(
        self, session_id: Optional[str], browser_device_id: str
    ) -> SessionContext:
        """Get existing session or create new one.

        Args:
            session_id: Existing session ID (optional)
            browser_device_id: Browser/device fingerprint

        Returns:
            SessionContext instance
        """
        if session_id:
            session = self.get_session(session_id)
            if session:
                # Validate device match
                if session.browser_device_id != browser_device_id:
                    # Device switch - require re-authentication
                    session.authenticated = False

                return session

        # Create new session
        return self.create_session(browser_device_id)

    @retry_on_db_error(max_attempts=3)
    def restore_session(
        self, session_id: str, browser_device_id: str
    ) -> Optional[SessionContext]:
        """Restore an expired session from database.

        Args:
            session_id: Session ID to restore
            browser_device_id: Browser/device fingerprint for validation

        Returns:
            Restored SessionContext or None if not found or device mismatch
        """
        with get_db_session() as db_session:
            expired_session = db_session.query(SessionContext).filter(
                SessionContext.session_id == session_id,
                SessionContext.expired == True
            ).first()

            if not expired_session:
                return None

            # Validate device match
            if expired_session.browser_device_id != browser_device_id:
                # Different device - require re-authentication
                return None

            # Restore session
            expired_session.last_activity = datetime.utcnow()
            expired_session.authenticated = True
            expired_session.expired = False

            db_session.add(expired_session)

            return expired_session

    def generate_browser_device_id(
        self, user_agent: str, accept_language: str = "", remote_addr: str = ""
    ) -> str:
        """Generate browser/device fingerprint for tab isolation.

        Args:
            user_agent: User-Agent header
            accept_language: Accept-Language header
            remote_addr: Remote IP address

        Returns:
            Unique device ID hash
        """
        fingerprint = f"{user_agent}|{accept_language}|{remote_addr}"
        return hashlib.sha256(fingerprint.encode()).hexdigest()[:32]

    def validate_device(
        self, session: SessionContext, current_device_id: str
    ) -> bool:
        """Validate device match for security.

        Args:
            session: Session to validate
            current_device_id: Current device fingerprint

        Returns:
            True if device matches
        """
        return session.browser_device_id == current_device_id
