"""Chat processing service."""

from typing import Optional, Tuple

from src.models.session import SessionContext


class ChatService:
    """Service for chat processing."""

    def __init__(self):
        """Initialize chat service."""
        pass

    def resolve_image_id(
        self, session: SessionContext, explicit_image_id: Optional[str]
    ) -> Tuple[Optional[str], Optional[str]]:
        """Resolve which image to use for chat.

        Args:
            session: Current session
            explicit_image_id: Explicit image ID override (optional)

        Returns:
            Tuple of (image_id, error_message)
        """
        # Check explicit override first
        if explicit_image_id:
            return explicit_image_id, None

        # Use session default
        if session.current_image_id:
            return session.current_image_id, None

        # No image available
        return None, "Please upload an image first"

    def chat(
        self,
        prompt: str,
        image_id: Optional[str] = None,
        history: Optional[list] = None,
        delay: float = 0.2,
        vision_analysis: Optional[str] = None,
    ) -> dict:
        """Generate chat response with optional conversation history.

        Args:
            prompt: User's chat prompt
            image_id: ID of image being discussed (None for text-only)
            history: Optional conversation history in OpenAI messages format
            delay: Simulated processing delay
            vision_analysis: Pre-computed vision analysis to use (from upload)

        Returns:
            OpenAI-compatible chat completion response
        """
        from src.services.mock_openai_service import mock_openai_chat

        return mock_openai_chat(
            prompt=prompt, image_id=image_id, history=history, stream=False, delay=delay,
            vision_analysis=vision_analysis,
        )

    def stream_chat(
        self,
        prompt: str,
        image_id: Optional[str] = None,
        history: Optional[list] = None,
        delay: float = 0.2,
        timeout_seconds: float = 30,
        vision_analysis: Optional[str] = None,
    ):
        """Generate streaming chat response with optional conversation history.

        Args:
            prompt: User's chat prompt
            image_id: ID of image being discussed (None for text-only)
            history: Optional conversation history in OpenAI messages format
            delay: Simulated processing delay
            timeout_seconds: Max stream duration
            vision_analysis: Pre-computed vision analysis to stream (from upload)

        Returns:
            Generator yielding SSE-formatted chunks
        """
        from src.services.mock_openai_service import mock_openai_chat

        return mock_openai_chat(
            prompt=prompt,
            image_id=image_id,
            history=history,
            stream=True,
            delay=delay,
            timeout_seconds=timeout_seconds,
            vision_analysis=vision_analysis,
        )
