"""In-memory caching service for conversation history with TTL and invalidation."""

import threading
import time
from typing import Dict, Optional, List
from datetime import datetime

from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class CacheEntry:
    """Represents a cached item with TTL and access tracking."""

    def __init__(self, data: Dict, ttl_seconds: int = 300):
        """Initialize cache entry.

        Args:
            data: Data to cache
            ttl_seconds: Time-to-live in seconds (default: 5 minutes)
        """
        self.data = data
        self.created_at = time.time()
        self.last_accessed = time.time()
        self.ttl_seconds = ttl_seconds
        self.access_count = 0

    def is_expired(self) -> bool:
        """Check if cache entry has expired."""
        return time.time() - self.created_at > self.ttl_seconds

    def touch(self) -> None:
        """Update access timestamp and count."""
        self.last_accessed = time.time()
        self.access_count += 1

    def get_data(self):
        """Get cached data (updates last_accessed)."""
        self.touch()
        return self.data


class ConversationCacheService:
    """In-memory cache for conversation history with thread-safe operations.

    Features:
    - TTL-based expiration (5 minutes default)
    - LRU eviction when memory limit reached
    - Cache invalidation on updates
    - Thread-safe with RLock
    """

    def __init__(self, max_size: int = 1000, default_ttl: int = 300):
        """Initialize cache service.

        Args:
            max_size: Maximum number of cached conversations (default: 1000)
            default_ttl: Default TTL in seconds (default: 300 = 5 minutes)
        """
        self.max_size = max_size
        self.default_ttl = default_ttl

        # Cache indexed by conversation_id
        self._conversations_cache: Dict[str, CacheEntry] = {}

        # Image-to-conversations index for quick lookup and invalidation
        self._image_cache_index: Dict[str, set] = {}

        # Session-to-conversations index
        self._session_cache_index: Dict[str, set] = {}

        # Thread safety
        self._lock = threading.RLock()

        # Stats tracking
        self._hits = 0
        self._misses = 0

        logger.info(
            f"ConversationCacheService initialized: "
            f"max_size={max_size}, ttl={default_ttl}s"
        )

    def get(self, conversation_id: str) -> Optional[Dict]:
        """Get conversation from cache.

        Args:
            conversation_id: Conversation ID to retrieve

        Returns:
            Cached conversation or None if not found/expired
        """
        with self._lock:
            entry = self._conversations_cache.get(conversation_id)

            if not entry:
                self._misses += 1
                logger.info(f"🔴 Cache MISS: {conversation_id} (not cached) | hits={self._hits} misses={self._misses}")
                return None

            if entry.is_expired():
                age = time.time() - entry.created_at
                del self._conversations_cache[conversation_id]
                self._misses += 1
                logger.info(f"🟡 Cache EXPIRED: {conversation_id} (age={age:.0f}s, ttl={entry.ttl_seconds}s) | hits={self._hits} misses={self._misses}")
                return None

            self._hits += 1
            age = time.time() - entry.created_at
            data = entry.get_data()
            logger.info(f"🟢 Cache HIT: {conversation_id} (age={age:.0f}s/{entry.ttl_seconds}s, accesses={entry.access_count}) | hits={self._hits} misses={self._misses}")
            return data

    def set(
        self,
        conversation_id: str,
        data: Dict,
        image_id: Optional[str] = None,
        session_id: Optional[str] = None,
        ttl: Optional[int] = None,
    ) -> None:
        """Cache a conversation.

        Args:
            conversation_id: Conversation ID
            data: Conversation data to cache
            image_id: Associated image ID (for invalidation)
            session_id: Associated session ID (for invalidation)
            ttl: Custom TTL in seconds (default: self.default_ttl)
        """
        with self._lock:
            # Check if we need to evict (LRU)
            if len(self._conversations_cache) >= self.max_size:
                self._evict_lru()

            # Cache the conversation
            ttl_to_use = ttl or self.default_ttl
            entry = CacheEntry(data, ttl_seconds=ttl_to_use)
            self._conversations_cache[conversation_id] = entry
            logger.info(f"📦 Cache SET: {conversation_id} (ttl={ttl_to_use}s, cache_size={len(self._conversations_cache)})")

            # Update indexes for invalidation
            if image_id:
                if image_id not in self._image_cache_index:
                    self._image_cache_index[image_id] = set()
                self._image_cache_index[image_id].add(conversation_id)

            if session_id:
                if session_id not in self._session_cache_index:
                    self._session_cache_index[session_id] = set()
                self._session_cache_index[session_id].add(conversation_id)

            logger.debug(
                f"Cached conversation {conversation_id} (ttl={ttl_to_use}s)"
            )

    def invalidate(self, conversation_id: str) -> None:
        """Invalidate a specific conversation from cache.

        Args:
            conversation_id: Conversation ID to invalidate
        """
        with self._lock:
            if conversation_id in self._conversations_cache:
                del self._conversations_cache[conversation_id]
                logger.debug(f"Invalidated conversation {conversation_id}")

    def invalidate_by_image(self, image_id: str) -> int:
        """Invalidate all conversations associated with an image.

        Args:
            image_id: Image ID

        Returns:
            Number of conversations invalidated
        """
        with self._lock:
            conversation_ids = self._image_cache_index.get(image_id, set()).copy()

            for conv_id in conversation_ids:
                if conv_id in self._conversations_cache:
                    del self._conversations_cache[conv_id]

            if image_id in self._image_cache_index:
                del self._image_cache_index[image_id]

            if conversation_ids:
                logger.info(
                    f"Invalidated {len(conversation_ids)} conversations for image {image_id}"
                )

            return len(conversation_ids)

    def invalidate_by_session(self, session_id: str) -> int:
        """Invalidate all conversations in a session.

        Args:
            session_id: Session ID

        Returns:
            Number of conversations invalidated
        """
        with self._lock:
            conversation_ids = self._session_cache_index.get(session_id, set()).copy()

            for conv_id in conversation_ids:
                if conv_id in self._conversations_cache:
                    del self._conversations_cache[conv_id]

            if session_id in self._session_cache_index:
                del self._session_cache_index[session_id]

            if conversation_ids:
                logger.info(
                    f"Invalidated {len(conversation_ids)} conversations for session {session_id}"
                )

            return len(conversation_ids)

    def clear(self) -> None:
        """Clear all cached data."""
        with self._lock:
            size = len(self._conversations_cache)
            self._conversations_cache.clear()
            self._image_cache_index.clear()
            self._session_cache_index.clear()
            logger.info(f"Cache cleared: {size} entries removed")

    def _evict_lru(self) -> None:
        """Evict least recently used entry (called with lock held)."""
        if not self._conversations_cache:
            return

        # Find least recently accessed
        lru_id = min(
            self._conversations_cache.keys(),
            key=lambda k: self._conversations_cache[k].last_accessed,
        )

        del self._conversations_cache[lru_id]
        logger.debug(f"LRU eviction: removed {lru_id}")

    def get_stats(self) -> Dict:
        """Get cache statistics.

        Returns:
            Dict with hit rate, entry count, etc.
        """
        with self._lock:
            total_requests = self._hits + self._misses
            hit_rate = (
                (self._hits / total_requests * 100) if total_requests > 0 else 0
            )

            return {
                "hits": self._hits,
                "misses": self._misses,
                "total_requests": total_requests,
                "hit_rate_percent": round(hit_rate, 2),
                "cached_conversations": len(self._conversations_cache),
                "max_size": self.max_size,
                "utilization_percent": round(
                    len(self._conversations_cache) / self.max_size * 100, 2
                ),
            }

    def reset_stats(self) -> None:
        """Reset cache statistics."""
        with self._lock:
            self._hits = 0
            self._misses = 0
            logger.debug("Cache stats reset")
