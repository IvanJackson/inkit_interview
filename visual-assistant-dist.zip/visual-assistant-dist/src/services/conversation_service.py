"""Conversation history storage and retrieval service with database persistence."""

import threading
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from sqlalchemy import desc

from src.models.conversation import Conversation
from src.models.message import Message
from src.database.connection import get_db_session
from src.database.errors import retry_on_db_error
from src.utils.logger import setup_logger
from src.services.cache_service import ConversationCacheService

logger = setup_logger(__name__)


class ConversationService:
    """Manages conversation history with database persistence and caching.

    Provides conversation creation, message storage, and context retrieval
    with truncation for AI prompts. All data persists across server restarts.
    Includes in-memory caching for improved response times.
    """

    def __init__(self, cache_service: Optional[ConversationCacheService] = None):
        """Initialize conversation service.

        Args:
            cache_service: Optional cache service instance (creates new if not provided)
        """
        self.cache = cache_service or ConversationCacheService(
            max_size=1000, default_ttl=300
        )
        logger.info("ConversationService initialized with database persistence and caching")

    @retry_on_db_error(max_attempts=3)
    def get_or_create_conversation(
        self, image_id: Optional[str], session_id: str
    ) -> Conversation:
        """Get existing conversation or create new one for image/session pair.

        Uses image_id as primary lookup key. This enables conversation continuity
        across session changes - users can continue discussing the same image even
        after session expiration.

        Args:
            image_id: Image being discussed (None for text-only conversations)
            session_id: Current session ID

        Returns:
            Conversation object (existing or newly created)
        """
        try:
            with get_db_session() as db_session:
                # Lookup strategy: Find most recent conversation by image_id
                if image_id:
                    conversation = db_session.query(Conversation).filter(
                        Conversation.image_id == image_id
                    ).order_by(desc(Conversation.created_at)).first()

                    if conversation:
                        logger.debug(
                            f"Retrieved existing conversation {conversation.conversation_id} "
                            f"for image_id={image_id}"
                        )
                        return conversation

                # No existing conversation - create new one
                conversation_id = f"conv-{uuid.uuid4()}"
                conversation = Conversation(
                    conversation_id=conversation_id,
                    session_id=session_id,
                    image_id=image_id,
                )

                db_session.add(conversation)

                logger.info(
                    f"Created new conversation {conversation_id} "
                    f"(image_id={image_id}, session_id={session_id})"
                )
                return conversation
        except Exception as e:
            logger.error(
                f"Failed to get or create conversation (image_id={image_id}, session_id={session_id}): {e}",
                exc_info=True,
            )
            raise

    @retry_on_db_error(max_attempts=3)
    def add_message(
        self, conversation_id: str, role: str, content: str
    ) -> Optional[Message]:
        """Add a message to conversation history.

        Implements graceful degradation (FR-012) - errors are logged but not
        raised, so history storage failures don't block chat requests.

        Args:
            conversation_id: Target conversation ID
            role: "user" or "assistant"
            content: Message text (max 50,000 characters)

        Returns:
            Created Message object, or None if operation failed
        """
        try:
            with get_db_session() as db_session:
                # Verify conversation exists
                conversation = db_session.query(Conversation).filter(
                    Conversation.conversation_id == conversation_id
                ).first()

                if not conversation:
                    logger.error(
                        f"Cannot add message: conversation {conversation_id} not found"
                    )
                    return None

                # Create message
                message_id = f"msg-{uuid.uuid4()}"
                message = Message(
                    message_id=message_id,
                    conversation_id=conversation_id,
                    role=role,
                    content=content,
                )

                # Store message
                db_session.add(message)

                # Update conversation last_activity
                conversation.touch()
                db_session.add(conversation)

                logger.info(
                    f"✓ Added {role} message {message_id} to conversation {conversation_id} "
                    f"({len(content)} chars, ~{message.token_count} tokens)"
                )
                return message

        except ValueError as e:
            # Message validation failed (invalid role or content too long)
            logger.error(
                f"Message validation failed for conversation {conversation_id}: {e}",
                exc_info=True,
            )
            return None
        except Exception as e:
            # Unexpected error - log but don't raise (graceful degradation)
            logger.error(
                f"Failed to add message to conversation {conversation_id}: {e}",
                exc_info=True,
            )
            # Invalidate cache for this conversation since we added a message
            self.cache.invalidate(conversation_id)
            return None

    @retry_on_db_error(max_attempts=3)
    def get_conversation_details(self, conversation_id: str) -> Optional[Dict]:
        """Get cached conversation details including all messages.

        Uses cache to speed up repeated requests for the same conversation.
        Cache is invalidated when new messages are added.

        Args:
            conversation_id: Conversation ID

        Returns:
            Dict with conversation metadata and messages, or None if not found
        """
        # Try cache first
        cached = self.cache.get(conversation_id)
        if cached:
            logger.debug(f"Cache hit for conversation: {conversation_id}")
            return cached

        try:
            with get_db_session() as db_session:
                conversation = db_session.query(Conversation).filter(
                    Conversation.conversation_id == conversation_id
                ).first()

                if not conversation:
                    return None

                # Get messages
                messages = db_session.query(Message).filter(
                    Message.conversation_id == conversation_id
                ).order_by(Message.created_at).all()

                # Build response dict
                response = {
                    "conversation_id": conversation.conversation_id,
                    "image_id": conversation.image_id,
                    "session_id": conversation.session_id,
                    "created_at": conversation.created_at.isoformat() + "Z",
                    "last_activity": conversation.last_activity.isoformat() + "Z",
                    "messages": [
                        {
                            "message_id": msg.message_id,
                            "role": msg.role,
                            "content": msg.content,
                            "created_at": msg.created_at.isoformat() + "Z",
                            "token_count": msg.token_count,
                        }
                        for msg in messages
                    ],
                }

                # Cache the result
                self.cache.set(
                    conversation_id,
                    response,
                    image_id=conversation.image_id,
                    session_id=conversation.session_id
                )

                return response

        except Exception as e:
            logger.error(
                f"Failed to get conversation details {conversation_id}: {e}",
                exc_info=True,
            )
            return None

    def get_cache_stats(self) -> Dict:
        """Get cache statistics for monitoring.

        Returns:
            Dict with hit rate, entry count, etc.
        """
        return self.cache.get_stats()

    @retry_on_db_error(max_attempts=3)
    def get_messages(self, conversation_id: str) -> List[Message]:
        """Get all messages for a conversation in chronological order.

        Args:
            conversation_id: Conversation ID to retrieve messages for

        Returns:
            List of Message objects (may be empty if conversation not found)
        """
        try:
            with get_db_session() as db_session:
                messages = db_session.query(Message).filter(
                    Message.conversation_id == conversation_id
                ).order_by(Message.created_at).all()

                if not messages:
                    logger.warning(
                        f"No messages found for conversation {conversation_id}"
                    )
                    return []

                logger.debug(
                    f"Retrieved {len(messages)} messages for conversation {conversation_id}"
                )
                return messages

        except Exception as e:
            logger.error(
                f"Failed to retrieve messages for conversation {conversation_id}: {e}",
                exc_info=True,
            )
            return []  # Return empty list on error

    @retry_on_db_error(max_attempts=3)
    def get_context_for_ai(
        self, conversation_id: str, max_messages: int = 50, max_tokens: int = 10_000
    ) -> List[Dict[str, str]]:
        """Get conversation history formatted for AI context injection.

        Implements context truncation (FR-015): Returns last N messages or
        up to M tokens, whichever limit is reached first. This prevents
        exceeding AI model context windows.

        Format matches OpenAI API messages array (Decision 6 in research.md):
        [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]

        Args:
            conversation_id: Conversation to retrieve context from
            max_messages: Maximum number of messages to include (default: 50)
            max_tokens: Maximum tokens to include (default: 10,000)

        Returns:
            List of message dicts in OpenAI format, ordered chronologically
        """
        try:
            with get_db_session() as db_session:
                # Get messages in reverse chronological order for truncation
                messages = db_session.query(Message).filter(
                    Message.conversation_id == conversation_id
                ).order_by(desc(Message.created_at)).all()

                if not messages:
                    return []

                # Truncation algorithm: Start from most recent, work backwards
                context: List[Dict[str, str]] = []
                total_tokens = 0

                for msg in messages:
                    # Check both limits
                    if len(context) >= max_messages or total_tokens >= max_tokens:
                        break

                    # Add message to context (will be reversed later)
                    context.insert(
                        0,  # Insert at beginning to maintain chronological order
                        {"role": msg.role, "content": msg.content},
                    )
                    total_tokens += msg.token_count

                logger.debug(
                    f"Retrieved context for conversation {conversation_id}: "
                    f"{len(context)} messages, ~{total_tokens} tokens"
                )
                return context

        except Exception as e:
            logger.error(
                f"Failed to retrieve context for conversation {conversation_id}: {e}",
                exc_info=True,
            )
            return []  # Return empty context on error

    @retry_on_db_error(max_attempts=3)
    def get_conversations_by_image(self, image_id: str) -> List[Conversation]:
        """Get all conversations associated with an image.

        Caches conversation metadata for faster retrieval on subsequent requests.

        Args:
            image_id: Image ID to look up

        Returns:
            List of Conversation objects (may be empty)
        """
        try:
            with get_db_session() as db_session:
                conversations = db_session.query(Conversation).filter(
                    Conversation.image_id == image_id
                ).order_by(desc(Conversation.created_at)).all()

                logger.debug(
                    f"Found {len(conversations)} conversations for image {image_id}"
                )
                return conversations

        except Exception as e:
            logger.error(
                f"Failed to retrieve conversations for image {image_id}: {e}",
                exc_info=True,
            )
            return []  # Return empty list on error

    @retry_on_db_error(max_attempts=3)
    def get_conversations_by_session(self, session_id: str) -> List[Conversation]:
        """Get all conversations in a session.

        Args:
            session_id: Session ID to look up

        Returns:
            List of Conversation objects (may be empty)
        """
        try:
            with get_db_session() as db_session:
                conversations = db_session.query(Conversation).filter(
                    Conversation.session_id == session_id
                ).order_by(desc(Conversation.created_at)).all()

                logger.debug(
                    f"Found {len(conversations)} conversations for session {session_id}"
                )
                return conversations

        except Exception as e:
            logger.error(
                f"Failed to retrieve conversations for session {session_id}: {e}",
                exc_info=True,
            )
            return []  # Return empty list on error

    @retry_on_db_error(max_attempts=3)
    def cleanup_old_conversations(
        self, retention_days: int, grace_period_days: int
    ) -> int:
        """Remove conversations older than retention period.

        Only deletes conversations where last_activity is older than
        (retention_days + grace_period_days). This prevents deleting
        active conversations that users are still engaged with.

        Args:
            retention_days: Base retention period (e.g., 30 days)
            grace_period_days: Additional grace period for active conversations (e.g., 7 days)

        Returns:
            Number of conversations deleted
        """
        try:
            with get_db_session() as db_session:
                cutoff_time = datetime.utcnow() - timedelta(
                    days=(retention_days + grace_period_days)
                )

                # Find conversations to delete
                old_conversations = db_session.query(Conversation).filter(
                    Conversation.last_activity < cutoff_time
                ).all()

                deleted_count = len(old_conversations)

                # Delete conversations (messages cascade automatically via foreign key)
                for conversation in old_conversations:
                    db_session.delete(conversation)

                if deleted_count > 0:
                    logger.info(
                        f"Cleaned up {deleted_count} conversations older than "
                        f"{retention_days + grace_period_days} days"
                    )
                else:
                    logger.debug("No conversations eligible for cleanup")

                return deleted_count

        except Exception as e:
            logger.error(
                f"Failed to cleanup old conversations: {e}",
                exc_info=True,
            )
            return 0  # Return 0 deleted on error


def start_cleanup_thread(
    conversation_service: ConversationService,
    cleanup_interval_seconds: int,
    retention_days: int,
    grace_period_days: int,
) -> threading.Thread:
    """Start background thread for periodic conversation cleanup.

    Creates a daemon thread that runs cleanup every N seconds. The thread
    runs asynchronously and doesn't block user requests (FR-017).

    Args:
        conversation_service: Service instance to clean up
        cleanup_interval_seconds: Seconds between cleanup runs (e.g., 3600 for hourly)
        retention_days: Base retention period
        grace_period_days: Grace period for active conversations

    Returns:
        Thread object (already started)
    """

    def cleanup_loop():
        """Cleanup loop that runs in background thread."""
        logger.info(
            f"Cleanup thread started: running every {cleanup_interval_seconds}s, "
            f"retention {retention_days}d + grace {grace_period_days}d"
        )

        while True:
            try:
                # Sleep first to avoid immediate cleanup on startup
                threading.Event().wait(cleanup_interval_seconds)

                # Run cleanup
                conversation_service.cleanup_old_conversations(
                    retention_days=retention_days, grace_period_days=grace_period_days
                )

            except Exception as e:
                # Log errors but don't crash the cleanup thread
                logger.error(f"Error in cleanup thread: {e}", exc_info=True)

    # Create and start daemon thread
    thread = threading.Thread(target=cleanup_loop, daemon=True, name="history-cleanup")
    thread.start()

    logger.info("Conversation history cleanup thread started")
    return thread
