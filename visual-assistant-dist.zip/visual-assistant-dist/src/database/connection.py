"""Database connection management with pooling and session handling."""

import os
from contextlib import contextmanager
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.pool import QueuePool


# Global engine and session factory (initialized on startup)
_engine = None
_SessionFactory = None


def init_connection_pool(database_url: str = None, pool_size: int = None):
    """
    Initialize database connection pool with QueuePool.

    Args:
        database_url: Database connection string
                     Defaults to DATABASE_URL env var or SQLite
        pool_size: Maximum number of connections in pool
                  Defaults to 5 for dev (SQLite), 20 for prod (PostgreSQL)

    Returns:
        SQLAlchemy engine instance
    """
    global _engine, _SessionFactory

    if database_url is None:
        database_url = os.getenv(
            'DATABASE_URL',
            'sqlite:///./data/visual_assistant.db'
        )

    # Determine pool size based on database type
    if pool_size is None:
        if database_url.startswith('sqlite'):
            pool_size = 5  # Development
        else:
            pool_size = 20  # Production

    # SQLite-specific configuration
    connect_args = {}
    if database_url.startswith('sqlite'):
        connect_args = {"check_same_thread": False}
        # Ensure data directory exists
        os.makedirs('./data', exist_ok=True)

    # Create engine with QueuePool
    _engine = create_engine(
        database_url,
        poolclass=QueuePool,
        pool_size=pool_size,
        max_overflow=10,  # Allow 10 extra connections beyond pool_size
        pool_timeout=30,  # Wait up to 30 seconds for connection
        pool_pre_ping=True,  # Verify connections before using
        pool_recycle=3600,  # Recycle connections after 1 hour
        connect_args=connect_args,
        echo=False  # Set to True for SQL debugging
    )

    # SQLite-specific: Enable foreign key constraints
    if database_url.startswith('sqlite'):
        @event.listens_for(_engine, "connect")
        def set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    # Create scoped session factory
    _SessionFactory = scoped_session(
        sessionmaker(
            bind=_engine,
            autocommit=False,
            autoflush=False,
            expire_on_commit=False
        )
    )

    return _engine


def get_engine():
    """Get the database engine instance."""
    if _engine is None:
        raise RuntimeError(
            "Database not initialized. Call init_connection_pool() first."
        )
    return _engine


def get_session_factory():
    """Get the session factory for creating database sessions."""
    if _SessionFactory is None:
        raise RuntimeError(
            "Database not initialized. Call init_connection_pool() first."
        )
    return _SessionFactory


@contextmanager
def get_db_session():
    """
    Context manager for database sessions with automatic transaction handling.

    Handles:
    - Commit on success
    - Rollback on exception
    - Close in finally block

    Usage:
        with get_db_session() as session:
            session.add(obj)
            # Automatically commits on success, rolls back on exception

    Yields:
        SQLAlchemy session with automatic commit/rollback/close
    """
    session = get_session_factory()()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_pool_status():
    """
    Get current connection pool statistics.

    Returns:
        dict: Pool status with size, checked_in, checked_out, overflow, etc.
    """
    if _engine is None:
        return {"error": "Database not initialized"}

    pool = _engine.pool
    return {
        "size": pool.size(),
        "checked_in": pool.checkedin(),
        "checked_out": pool.checkedout(),
        "overflow": pool.overflow(),
        "timeout": pool.timeout(),
    }


def health_check():
    """
    Verify database connection is healthy.

    Returns:
        bool: True if connection successful, False otherwise
    """
    try:
        with get_db_session() as session:
            session.execute("SELECT 1")
        return True
    except Exception:
        return False
