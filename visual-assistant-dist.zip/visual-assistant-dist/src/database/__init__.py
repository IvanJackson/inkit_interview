"""Database initialization and configuration."""

import logging
import os
from .connection import init_connection_pool, get_engine, get_session_factory
from .migrations import run_migrations
from ..models.base import Base

logger = logging.getLogger(__name__)


def init_database(database_url: str = None, run_migrations_on_startup: bool = True):
    """
    Initialize database engine, session factory, and run migrations.

    This function should be called once during application startup.

    Args:
        database_url: Database connection string
                     Defaults to DATABASE_URL env var or sqlite:///./data/visual_assistant.db
        run_migrations_on_startup: Whether to run migrations automatically (default: True)

    Returns:
        SQLAlchemy engine instance

    Raises:
        Exception: If database initialization or migration fails
    """
    try:
        # Get database URL
        if database_url is None:
            database_url = os.getenv(
                'DATABASE_URL',
                'sqlite:///./data/visual_assistant.db'
            )

        logger.info(f"Initializing database: {database_url.split('://')[0]}://...")

        # Initialize connection pool
        engine = init_connection_pool(database_url)

        logger.info("✓ Database connection pool initialized")

        # Run migrations if enabled
        if run_migrations_on_startup:
            run_migrations()

        logger.info("✓ Database initialization complete")

        return engine

    except Exception as e:
        logger.error(f"✗ Database initialization failed: {str(e)}")
        raise


def create_all_tables():
    """
    Create all database tables directly (bypass migrations).

    This is useful for testing or initial setup without Alembic.
    For production, use migrations instead.
    """
    try:
        logger.info("Creating all database tables...")
        Base.metadata.create_all(bind=get_engine())
        logger.info("✓ All tables created successfully")
    except Exception as e:
        logger.error(f"✗ Failed to create tables: {str(e)}")
        raise


def drop_all_tables():
    """
    Drop all database tables.

    WARNING: This is a destructive operation. Use with caution.
    Only for testing or database reset.
    """
    try:
        logger.warning("Dropping all database tables...")
        Base.metadata.drop_all(bind=get_engine())
        logger.info("✓ All tables dropped")
    except Exception as e:
        logger.error(f"✗ Failed to drop tables: {str(e)}")
        raise


# Export commonly used functions
__all__ = [
    'init_database',
    'create_all_tables',
    'drop_all_tables',
    'get_engine',
    'get_session_factory',
]
