"""Database error handling with custom exceptions and HTTP status mapping."""

import time
import logging
from functools import wraps
from sqlalchemy.exc import (
    IntegrityError,
    OperationalError,
    DatabaseError,
    TimeoutError as SQLTimeoutError,
    DBAPIError
)

logger = logging.getLogger(__name__)


# Deadlock detection

def is_deadlock_exception(exc: Exception) -> bool:
    """
    Detect if exception was caused by database deadlock.

    Works with both SQLite and PostgreSQL:
    - PostgreSQL: 40P01 error code or "deadlock detected" message
    - SQLite: "database is locked" message with SQLITE_BUSY

    Args:
        exc: Exception to check

    Returns:
        True if exception indicates deadlock, False otherwise
    """
    if not isinstance(exc, DBAPIError):
        return False

    exc_str = str(exc).lower()
    orig_exception = getattr(exc, 'orig', None)
    
    # PostgreSQL deadlock detection
    if hasattr(exc, 'sqlstate'):
        if exc.sqlstate == '40P01':  # PostgreSQL deadlock code
            return True
    
    # Text-based detection (works with multiple databases)
    deadlock_indicators = [
        'deadlock detected',  # PostgreSQL
        'database is locked',  # SQLite
        'lock wait timeout',   # MySQL
    ]
    
    for indicator in deadlock_indicators:
        if indicator in exc_str:
            return True
    
    # Check original exception (if available)
    if orig_exception:
        orig_str = str(orig_exception).lower()
        for indicator in deadlock_indicators:
            if indicator in orig_str:
                return True
    
    return False


# Custom database exceptions

class DatabaseConnectionError(Exception):
    """Raised when database connection fails."""
    http_status = 503  # Service Unavailable
    pass


class DatabaseTimeoutError(Exception):
    """Raised when database operation times out."""
    http_status = 504  # Gateway Timeout
    pass


class DatabaseConstraintError(Exception):
    """Raised when database constraint is violated."""
    http_status = 409  # Conflict
    pass


class DatabaseError(Exception):
    """Generic database error."""
    http_status = 500  # Internal Server Error
    pass


# HTTP status code mapping

def map_db_exception_to_http_status(exc: Exception) -> int:
    """
    Map database exception to appropriate HTTP status code.

    Args:
        exc: Exception instance

    Returns:
        HTTP status code (int)
    """
    if isinstance(exc, (OperationalError, DatabaseConnectionError)):
        return 503  # Service Unavailable
    elif isinstance(exc, (SQLTimeoutError, DatabaseTimeoutError)):
        return 504  # Gateway Timeout
    elif isinstance(exc, (IntegrityError, DatabaseConstraintError)):
        return 409  # Conflict
    else:
        return 500  # Internal Server Error


def get_error_message_for_user(exc: Exception) -> str:
    """
    Get user-friendly error message for database exception.

    Args:
        exc: Exception instance

    Returns:
        User-friendly error message (str)
    """
    if isinstance(exc, (OperationalError, DatabaseConnectionError)):
        return "Database temporarily unavailable. Please try again later."
    elif isinstance(exc, (SQLTimeoutError, DatabaseTimeoutError)):
        return "Database operation timed out. Please try again."
    elif isinstance(exc, (IntegrityError, DatabaseConstraintError)):
        return "Data conflict detected. The operation could not be completed."
    else:
        return "An unexpected database error occurred. Please try again."


# Retry decorator with exponential backoff

def retry_on_db_error(max_attempts: int = 3, base_delay: float = 0.1, handle_deadlocks: bool = True):
    """
    Decorator to retry database operations with exponential backoff.

    Retries on transient errors (OperationalError, TimeoutError, Deadlock).
    Does NOT retry on constraint violations (IntegrityError).

    Args:
        max_attempts: Maximum number of retry attempts (default: 3)
        base_delay: Base delay in seconds for exponential backoff (default: 0.1)
        handle_deadlocks: Whether to retry on deadlock errors (default: True)

    Usage:
        @retry_on_db_error(max_attempts=3)
        def save_to_database(data):
            # Database operation here
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempt = 0
            last_exception = None

            while attempt < max_attempts:
                try:
                    return func(*args, **kwargs)

                except (OperationalError, SQLTimeoutError, DatabaseConnectionError) as e:
                    attempt += 1
                    last_exception = e

                    if attempt >= max_attempts:
                        logger.error(
                            f"Database operation failed after {max_attempts} attempts: "
                            f"{func.__name__} - {str(e)}"
                        )
                        raise

                    # Exponential backoff: 0.1s, 0.2s, 0.4s, 0.8s, ...
                    delay = base_delay * (2 ** (attempt - 1))
                    logger.warning(
                        f"Retrying database operation (attempt {attempt}/{max_attempts}) "
                        f"after {delay}s delay: {func.__name__} - {str(e)}"
                    )
                    time.sleep(delay)

                except DBAPIError as e:
                    # Check for deadlock and retry with increased delay
                    if handle_deadlocks and is_deadlock_exception(e):
                        attempt += 1
                        last_exception = e
                        
                        if attempt >= max_attempts:
                            logger.error(
                                f"Deadlock in {func.__name__} after {max_attempts} attempts: {str(e)}"
                            )
                            raise
                        
                        # Increased delay for deadlock (50ms per attempt)
                        delay = 0.05 * (2 ** attempt)
                        logger.warning(
                            f"Deadlock detected in {func.__name__}, retrying (attempt {attempt}/{max_attempts}) "
                            f"after {delay}s delay"
                        )
                        time.sleep(delay)
                    else:
                        # Not a deadlock - check if it's constraint violation
                        if isinstance(e, IntegrityError):
                            logger.error(f"Database constraint violation in {func.__name__}: {str(e)}")
                            raise DatabaseConstraintError(str(e))
                        else:
                            logger.error(f"Database API error in {func.__name__}: {str(e)}")
                            raise

                except IntegrityError as e:
                    # Don't retry constraint violations
                    logger.error(
                        f"Database constraint violation in {func.__name__}: {str(e)}"
                    )
                    raise DatabaseConstraintError(str(e))

                except Exception as e:
                    # Don't retry unexpected errors
                    logger.error(
                        f"Unexpected error in {func.__name__}: {str(e)}"
                    )
                    raise

            # Should not reach here, but just in case
            raise last_exception

        return wrapper
    return decorator
