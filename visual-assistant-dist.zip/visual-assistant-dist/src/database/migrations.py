"""Database migration runner for automatic schema updates on startup."""

import logging
import os
import time
import fcntl
from contextlib import contextmanager
from alembic import command
from alembic.config import Config
from alembic.runtime.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine

logger = logging.getLogger(__name__)


def get_alembic_config():
    """
    Get Alembic configuration object.

    Returns:
        Alembic Config object with configured paths
    """
    # Path to alembic.ini in project root
    alembic_cfg = Config("alembic.ini")

    # Override database URL from environment
    database_url = os.getenv('DATABASE_URL', 'sqlite:///./data/visual_assistant.db')
    alembic_cfg.set_main_option('sqlalchemy.url', database_url)

    return alembic_cfg


@contextmanager
def migration_lock(timeout: int = 300):
    """
    Acquire an exclusive lock for running migrations.

    Uses file-based locking to prevent concurrent migration execution.
    Multiple server instances trying to start simultaneously will queue
    and run migrations one at a time.

    Args:
        timeout: Maximum seconds to wait for lock (default: 300 = 5 minutes)

    Yields:
        None when lock is acquired

    Raises:
        TimeoutError: If lock cannot be acquired within timeout period
    """
    # Create locks directory
    os.makedirs('./data/locks', exist_ok=True)
    lock_file_path = './data/locks/migration.lock'

    lock_file = open(lock_file_path, 'w')
    start_time = time.time()

    try:
        logger.info("Attempting to acquire migration lock...")

        # Try to acquire exclusive lock with timeout
        while time.time() - start_time < timeout:
            try:
                # Non-blocking exclusive lock
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                logger.info("✓ Migration lock acquired")
                yield
                return
            except BlockingIOError:
                # Lock held by another process
                elapsed = time.time() - start_time
                remaining = timeout - elapsed
                logger.debug(
                    f"Migration lock held by another process. "
                    f"Waiting... ({remaining:.0f}s remaining)"
                )
                time.sleep(1)  # Wait 1 second before retry

        # Timeout exceeded
        raise TimeoutError(
            f"Could not acquire migration lock after {timeout} seconds. "
            "Another instance may be running migrations."
        )

    finally:
        # Release lock and close file
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
            logger.info("✓ Migration lock released")
        except Exception as e:
            logger.warning(f"Error releasing migration lock: {e}")
        finally:
            lock_file.close()


def check_pending_migrations():
    """
    Check if there are pending migrations to run.

    Returns:
        bool: True if pending migrations exist, False otherwise
    """
    try:
        alembic_cfg = get_alembic_config()
        database_url = alembic_cfg.get_main_option('sqlalchemy.url')

        # Create engine to check current version
        engine = create_engine(database_url)

        # Get migration context
        with engine.connect() as connection:
            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()

        # Get script directory
        script = ScriptDirectory.from_config(alembic_cfg)
        head_rev = script.get_current_head()

        if current_rev is None:
            logger.info("No migrations applied yet. Pending migrations detected.")
            return True

        if current_rev != head_rev:
            logger.info(
                f"Pending migrations detected. "
                f"Current: {current_rev}, Head: {head_rev}"
            )
            return True

        logger.info(f"Database is up to date at revision: {current_rev}")
        return False

    except Exception as e:
        logger.error(f"Error checking pending migrations: {str(e)}")
        return True  # Assume migrations needed if check fails


def run_migrations():
    """
    Run all pending database migrations with exclusive lock.

    This function is called automatically on application startup.
    Uses file-based locking to prevent concurrent migration execution
    when multiple server instances start simultaneously.

    Raises:
        Exception: If migration fails
        TimeoutError: If migration lock cannot be acquired
    """
    try:
        logger.info("Checking for pending database migrations...")

        if not check_pending_migrations():
            logger.info("No pending migrations. Database is up to date.")
            return

        logger.info("Running pending database migrations...")

        # Acquire exclusive lock to prevent concurrent migrations
        with migration_lock(timeout=300):
            alembic_cfg = get_alembic_config()

            # Double-check migrations still pending (another instance may have run them)
            if not check_pending_migrations():
                logger.info("Migrations already applied by another instance.")
                return

            # Run migrations
            command.upgrade(alembic_cfg, "head")

            logger.info("✓ Database migrations completed successfully")

    except TimeoutError as e:
        logger.error(f"✗ Migration lock timeout: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"✗ Database migration failed: {str(e)}")
        raise


