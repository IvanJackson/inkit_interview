"""Flask application factory for Visual Assistant API."""

import os
from flask import Flask, jsonify, send_from_directory

from config import config_by_name


def _init_database(app):
    """Initialize database connection and run migrations."""
    import logging
    from src.database import init_database

    # Configure colored logging with reduced verbosity
    class ColoredFormatter(logging.Formatter):
        """Add colors to log messages."""
        
        COLORS = {
            'INFO': '\033[92m',     # Green
            'WARNING': '\033[93m',  # Yellow
            'ERROR': '\033[91m',    # Red
            'DEBUG': '\033[94m',    # Blue
            'RESET': '\033[0m'      # Reset
        }
        
        def format(self, record):
            color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
            record.levelname = f"{color}{record.levelname}{self.COLORS['RESET']}"
            return super().format(record)

    # Set up colored logging
    handler = logging.StreamHandler()
    handler.setFormatter(ColoredFormatter('%(asctime)s - %(levelname)s - %(message)s', 
                                      datefmt='%H:%M:%S'))
    
    # Configure root logger
    logging.basicConfig(
        level=logging.INFO,
        handlers=[handler],
        force=True
    )
    
    # Suppress verbose logging from specific modules
    logging.getLogger('src.services.cache_service').setLevel(logging.WARNING)
    logging.getLogger('src.services.conversation_service').setLevel(logging.WARNING)
    logging.getLogger('alembic').setLevel(logging.WARNING)
    logging.getLogger('werkzeug').setLevel(logging.WARNING)

    print(f"\033[92m🗄️  Initializing database...\033[0m")
    init_database()
    print(f"\033[92m✅ Database ready\033[0m\n")


def _init_conversation_history(app):
    """Initialize conversation history service and start cleanup thread."""
    from src.api.chat import get_conversation_service
    from src.services.conversation_service import start_cleanup_thread

    print(f"\033[94m🧹 Starting cleanup thread...\033[0m")
    
    # Initialize conversation service (lazy initialization on first request)
    # The service will be created when first accessed via get_conversation_service()

    # Start background cleanup thread
    with app.app_context():
        conversation_service = get_conversation_service()
        start_cleanup_thread(
            conversation_service=conversation_service,
            cleanup_interval_seconds=app.config.get(
                "HISTORY_CLEANUP_INTERVAL_SECONDS", 3600
            ),
            retention_days=app.config.get("HISTORY_RETENTION_DAYS", 30),
            grace_period_days=app.config.get("HISTORY_GRACE_PERIOD_DAYS", 7),
        )
    
    print(f"\033[94m✅ Cleanup thread running\033[0m")


def create_app(config_name=None):
    """Create and configure the Flask application.

    Args:
        config_name: Configuration name ('development', 'testing', 'production').
                     Defaults to FLASK_ENV environment variable or 'development'.

    Returns:
        Configured Flask application instance.
    """
    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "development")

    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])

    # Ensure upload directory exists
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    # Initialize database (T027 - Q4 Persistent Storage)
    _init_database(app)

    # Initialize middleware
    _init_middleware(app)

    # Register blueprints
    _register_blueprints(app)

    # Initialize conversation history (Q3)
    _init_conversation_history(app)

    # Register error handlers
    _register_error_handlers(app)

    # Serve frontend
    @app.route("/")
    def index():
        return send_from_directory("static", "index.html")

    return app


def _init_middleware(app):
    """Initialize middleware components."""
    from src.api.middleware import init_middleware

    init_middleware(app)


def _register_blueprints(app):
    """Register Flask blueprints for API routes."""
    from src.api.upload import upload_bp
    from src.api.chat import chat_bp
    from src.api.history import history_bp

    app.register_blueprint(upload_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(history_bp, url_prefix="/chat")


def _register_error_handlers(app):
    """Register global error handlers returning OpenAI-compatible error format."""
    from src.utils.openai_formatter import format_error_response

    @app.errorhandler(400)
    def bad_request(e):
        return jsonify(format_error_response(
            message=str(e.description) if hasattr(e, "description") else "Bad request",
            error_type="invalid_request_error",
            code="bad_request",
        )), 400

    @app.errorhandler(404)
    def not_found(e):
        return jsonify(format_error_response(
            message="The requested resource was not found",
            error_type="invalid_request_error",
            code="not_found",
        )), 404

    @app.errorhandler(413)
    def payload_too_large(e):
        return jsonify(format_error_response(
            message="Image file exceeds maximum size of 16MB",
            error_type="invalid_request_error",
            param="image",
            code="image_too_large",
        )), 413

    @app.errorhandler(415)
    def unsupported_media_type(e):
        return jsonify(format_error_response(
            message="Unsupported image format. Accepted: JPEG, PNG, GIF, WebP",
            error_type="invalid_request_error",
            param="image",
            code="unsupported_format",
        )), 415

    @app.errorhandler(422)
    def unprocessable_entity(e):
        return jsonify(format_error_response(
            message=str(e.description) if hasattr(e, "description") else "Validation failed",
            error_type="invalid_request_error",
            code="validation_failed",
        )), 422

    @app.errorhandler(429)
    def rate_limit_exceeded(e):
        return jsonify(format_error_response(
            message="Rate limit exceeded. Please try again later.",
            error_type="rate_limit_exceeded",
            code="rate_limit_exceeded",
        )), 429

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify(format_error_response(
            message="An internal error occurred. Please try again later.",
            error_type="api_error",
            code="internal_error",
        )), 500

    @app.errorhandler(503)
    def service_unavailable(e):
        return jsonify(format_error_response(
            message="Too many active streaming connections. Please try again shortly.",
            error_type="api_error",
            code="streaming_capacity_exceeded",
        )), 503




# Application entry point
if __name__ == "__main__":
    print(f"\033[95m🚀 Starting Visual Assistant API...\033[0m")
    application = create_app()
    print(f"\033[95m🌐 Server running on http://127.0.0.1:5001\033[0m")
    print(f"\033[95m📸 Upload an image to get started!\033[0m\n")
    application.run(debug=True, threaded=True, port=5001)
