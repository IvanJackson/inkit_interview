# Visual Assistant API

A Flask-based REST API for image upload and AI-powered conversational analysis with real-time streaming responses. Uses a mock OpenAI service that returns OpenAI-compatible responses.

## Project Goal

Build a single-page web application where users can:
1. Upload an image
2. Receive initial analysis about the photo
3. Chat about that image with an AI assistant
4. Have persistent storage

Each conversation is tied to exactly one image. Uploading a new image starts a new conversation.

## Architecture

```
app.py                      # Flask application factory & entry point
config.py                   # Configuration (rate limits, paths, etc.)
static/
  index.html                # Single-page frontend (vanilla JS)
src/
  __init__.py
  api/
    __init__.py
    chat.py                 # /chat and /chat/stream endpoints
    upload.py               # /upload endpoint
    history.py              # /chat/history endpoint
    middleware.py           # CORS, session middleware
  services/
    __init__.py
    chat_service.py         # Chat logic (resolve image, call mock AI)
    mock_openai_service.py  # Mock OpenAI responses
    conversation_service.py # Conversation CRUD + cleanup
    image_service.py        # Image storage & validation
    session_service.py      # Session management
    cache_service.py        # In-memory conversation cache
  database/
    __init__.py
    connection.py           # SQLAlchemy connection pool
    migrations.py           # Alembic migration runner
    errors.py               # Database error handling
  models/
    __init__.py
    base.py                 # Declarative base
    chat.py                 # Chat model
    conversation.py         # Conversation model
    image.py                # Image model
    message.py              # Message model
    response.py             # Response model
    session.py              # Session model
  utils/
    __init__.py
    openai_formatter.py     # OpenAI-compatible response formatting
    security.py             # Input sanitization
    logger.py               # Logging setup
alembic/                    # Database migrations
```

## Quick Start

### Prerequisites
- Python 3.9+
- pip

### Setup

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python3 app.py
```

The app starts on **http://localhost:5001**. Open it in your browser to use the UI.

### Environment Variables (optional)

Copy `.env.example` to `.env` to customize settings. The app works out of the box with defaults (SQLite database, in-memory rate limiting).

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/` | Serves the frontend UI |
| `POST` | `/upload` | Upload an image (multipart form, field: `image`) |
| `POST` | `/chat` | Chat about an uploaded image (JSON: `prompt`, `image_id`) |
| `POST` | `/chat/stream` | Streaming chat via SSE (same body as `/chat`) |
| `GET` | `/chat/history` | Get conversation history |

### Upload Example

```bash
curl -X POST -F "image=@photo.jpg" http://localhost:5001/upload
```

### Chat Example

```bash
curl -X POST -H "Content-Type: application/json" \
  -d '{"prompt": "What do you see?", "image_id": "<image_id>"}' \
  http://localhost:5001/chat
```

## Key Features

- **Image requirement enforced**: Chat requires a valid uploaded image
- **One image per conversation**: New image = new conversation
- **OpenAI-compatible streaming**: SSE with `chat.completion.chunk` format 
- **Rate limiting**: 20 uploads/hour, 100 chats/minute (configurable in `config.py`)
- **Session management**: Cookie-based sessions with 24-hour expiry
- **SQLite database**: Auto-created with Alembic migrations on startup
- **Concurrent-safe**: Thread-safe database access, no shared mutable state

## Running Tests

The test suite requires the app to be running on `localhost:5001`.

```bash
# Start the app
python3 app.py

# In another terminal, run all tests
cd testing
bash run-complete-test-suite.sh
```

**Note**: Before running the full test suite, temporarily increase rate limits in `config.py` to avoid 429 errors:

```python
UPLOAD_RATE_LIMIT = "1000 per hour"
CHAT_RATE_LIMIT = "1000 per minute"
GLOBAL_RATE_LIMIT = "10000 per hour"
```

Remember to revert after testing.

### Test Suites (8 total)

1. **Core API Tests** - Health check, upload, chat, OpenAI format compliance
2. **Image Requirement** - Chat rejected without image, accepted with image
3. **Integration Tests** - Full workflow: upload -> chat -> history -> new conversation
4. **Performance Tests** - Concurrent users, file safety, rate limiting, DB performance
5. **Requirements Validation** - Concurrent safety, OpenAI format, image enforcement
6. **Advanced Automated** - Streaming reconnection, concurrent DB, cache, rate limiting
7. **Evidence Collection** - Automated performance metrics and compliance evidence
8. **Frontend Tests** - Manual browser-based UI validation

## Configuration

Key settings in `config.py`:

| Setting | Default | Description |
|---------|---------|-------------|
| `UPLOAD_RATE_LIMIT` | `20 per hour` | Max uploads per hour per session |
| `CHAT_RATE_LIMIT` | `100 per minute` | Max chat requests per minute per session |
| `MAX_CONTENT_LENGTH` | `16 MB` | Max upload file size |
| `MAX_IMAGE_WIDTH` | `4096` | Max image dimension |
| `SESSION_TIMEOUT_HOURS` | `24` | Session expiry |
| `ALLOWED_EXTENSIONS` | `jpeg, jpg, png, gif, webp` | Accepted image formats |
